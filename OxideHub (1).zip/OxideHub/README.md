# Oxide Hub — Android demo app

A native Android demo app built with Kotlin and Jetpack Compose. It is an unofficial fan project and is not affiliated with the Oxide game developers.

## Demo features
- Dark gaming-style home screen
- Survival tips and guide catalogue
- Demo digital shop with sample products and prices
- Shopping cart and demo checkout (does not charge money)
- Local display-name profile (not a real account)
- Local product manager for testing (demo PIN: `2468`)

## Important limitations
This is a test build, not a production store:
- Product list, profile, and cart are stored in app memory and may reset when the app closes.
- The admin PIN is visible in the source and is not secure.
- Checkout is only a demonstration; no payment is taken and no verified order is created.
- Real accounts, online admin, persistent orders, and real payment require a secure backend, database, and payment provider.
- The app does not modify Oxide or provide cheats.

## Build an APK using only your Android phone (GitHub Actions)
This project includes `.github/workflows/build-apk.yml` so GitHub can build the APK on its servers. You do not need to install AndroidIDE.

1. Download and extract `OxideHub.zip` on your phone.
2. Sign in to GitHub and create a new **empty repository** named `OxideHub`.
3. Upload the extracted project files and folders to the repository root. Make sure `.github/workflows/build-apk.yml` is uploaded too. If the mobile website does not allow uploading folders, use GitHub's web upload or the GitHub mobile app/browser in desktop mode.
4. Open the repository's **Actions** tab. Select **Build Oxide Hub APK** and tap **Run workflow**. (A push to `main` or `master` also starts a build.)
5. Wait for the workflow to finish successfully, open the completed run, scroll to **Artifacts**, and download `OxideHub-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it. Android may ask you to allow installation from your browser or file manager.

The GitHub Actions build uses a debug APK for testing. It is not a Play Store release build.

## Build settings
- Application ID: `com.amirvirus.oxidehub`
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle: 8.9 in the GitHub Actions workflow
