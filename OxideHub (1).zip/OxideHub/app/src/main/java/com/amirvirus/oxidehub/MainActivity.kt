package com.amirvirus.oxidehub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1B2832)
private val Orange = Color(0xFFFF8A32)
private val Mint = Color(0xFF8CE0B5)
private val Muted = Color(0xFF9EADB7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OxideHubApp() }
    }
}

data class ShopItem(val id: Int, val title: String, val subtitle: String, val price: Int, val tag: String)
data class CartLine(val item: ShopItem, val quantity: Int)

private val initialItems = listOf(
    ShopItem(1, "Starter Guide", "Beginner survival checklist", 0, "FREE"),
    ShopItem(2, "Base Building Pack", "Base layouts and building tips", 49000, "GUIDE"),
    ShopItem(3, "VIP Guide Bundle", "Advanced survival guide bundle", 99000, "VIP"),
    ShopItem(4, "Server Notes", "Personal checklist template", 29000, "TOOLS")
)

@Composable
fun OxideHubApp() {
    var tab by remember { mutableStateOf("Home") }
    var items by remember { mutableStateOf(initialItems) }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var message by remember { mutableStateOf("") }
    var showAdmin by remember { mutableStateOf(false) }
    var showLogin by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf("") }
    var loginInput by remember { mutableStateOf("") }
    var adminPin by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, secondary = Mint, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val destinations = listOf("Home", "Shop", "Orders", "Profile")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Storefront, Icons.Default.ReceiptLong, Icons.Default.Person)
                    destinations.forEachIndexed { index, destination ->
                        NavigationBarItem(
                            selected = tab == destination,
                            onClick = { tab = destination },
                            icon = { Icon(icons[index], contentDescription = destination) },
                            label = { Text(destination) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, indicatorColor = Ink, unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            },
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(38.dp).background(Brush.linearGradient(listOf(Orange, Color(0xFFCF4D26))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Terrain, contentDescription = null, tint = Ink)
                        }
                        Column {
                            Text("OXIDE HUB", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, color = Color.White)
                            Text("SURVIVE SMARTER", fontSize = 10.sp, color = Mint, letterSpacing = 1.3.sp)
                        }
                    }
                    BadgedBox(badge = { if (cart.isNotEmpty()) Badge(containerColor = Orange) { Text(cart.sumOf { it.quantity }.toString(), color = Ink) } }) {
                        IconButton(onClick = { tab = "Shop" }) { Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = Color.White) }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Home" -> HomeScreen(onShop = { tab = "Shop" }, onGuides = { tab = "Shop" }, onAdmin = { showAdmin = true })
                    "Shop" -> ShopScreen(items, cart, onAdd = { item ->
                        val existing = cart.find { it.item.id == item.id }
                        cart = if (existing == null) cart + CartLine(item, 1) else cart.map { if (it.item.id == item.id) it.copy(quantity = it.quantity + 1) else it }
                        message = "${item.title} added to cart"
                    }, onCheckout = { tab = "Orders" })
                    "Orders" -> OrdersScreen(cart, onRemove = { id -> cart = cart.filterNot { it.item.id == id } }, onCheckout = {
                        message = "Demo checkout only. No payment was taken. Connect a verified payment provider before selling."
                    })
                    else -> ProfileScreen(userName, onLogin = { showLogin = true }, onAdmin = { showAdmin = true })
                }
                if (message.isNotBlank()) {
                    AlertDialog(onDismissRequest = { message = "" }, confirmButton = { TextButton(onClick = { message = "" }) { Text("OK", color = Orange) } }, title = { Text("Oxide Hub") }, text = { Text(message) }, containerColor = Panel)
                }
                if (showLogin) {
                    AlertDialog(
                        onDismissRequest = { showLogin = false },
                        title = { Text("Create local profile") },
                        text = { OutlinedTextField(value = loginInput, onValueChange = { loginInput = it }, label = { Text("Display name") }, singleLine = true) },
                        confirmButton = { TextButton(onClick = { if (loginInput.isNotBlank()) userName = loginInput.trim(); showLogin = false; loginInput = "" }) { Text("Save", color = Orange) } },
                        dismissButton = { TextButton(onClick = { showLogin = false }) { Text("Cancel") } },
                        containerColor = Panel
                    )
                }
                if (showAdmin) {
                    var unlocked by remember { mutableStateOf(false) }
                    var productTitle by remember { mutableStateOf("") }
                    var productPrice by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { showAdmin = false; adminPin = ""; unlocked = false },
                        title = { Text(if (unlocked) "Local product manager" else "Demo admin access") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (!unlocked) {
                                    Text("Demo PIN: 2468", color = Muted, fontSize = 12.sp)
                                    OutlinedTextField(value = adminPin, onValueChange = { adminPin = it }, label = { Text("Admin PIN") }, singleLine = true)
                                } else {
                                    Text("This manager only edits products on this device. It is not a secure online admin panel.", color = Muted, fontSize = 12.sp)
                                    OutlinedTextField(value = productTitle, onValueChange = { productTitle = it }, label = { Text("Product name") }, singleLine = true)
                                    OutlinedTextField(value = productPrice, onValueChange = { productPrice = it.filter(Char::isDigit) }, label = { Text("Price in toman (0 = free)") }, singleLine = true)
                                    Text("${items.size} products currently listed", color = Mint)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (!unlocked) { if (adminPin == "2468") unlocked = true else message = "Incorrect demo PIN" }
                                else if (productTitle.isNotBlank()) {
                                    val newId = (items.maxOfOrNull { it.id } ?: 0) + 1
                                    items = items + ShopItem(newId, productTitle.trim(), "Added from local admin", productPrice.toIntOrNull() ?: 0, "NEW")
                                    productTitle = ""; productPrice = ""; message = "Product added on this device"
                                }
                            }) { Text(if (unlocked) "Add product" else "Unlock", color = Orange) }
                        },
                        dismissButton = { TextButton(onClick = { showAdmin = false; adminPin = ""; unlocked = false }) { Text("Close") } },
                        containerColor = Panel
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onShop: () -> Unit, onGuides: () -> Unit, onAdmin: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF263B43), Color(0xFF111A20))), RoundedCornerShape(24.dp)).padding(22.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("SURVIVE THE ISLAND", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Your next run\nstarts here.", fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("Guides, community tools and digital packs for Oxide players.", color = Muted, fontSize = 14.sp)
                    Button(onClick = onShop, colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Ink), shape = RoundedCornerShape(12.dp)) {
                        Text("Explore shop", fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }
            }
        }
        item { SectionTitle("QUICK ACCESS", "Choose your next move") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Survival guides", "Tips for new players", Icons.Default.MenuBook, Modifier.weight(1f), onGuides)
                QuickCard("Digital shop", "Guides and packs", Icons.Default.ShoppingBag, Modifier.weight(1f), onShop)
            }
        }
        item { SectionTitle("FIELD NOTES", "Useful reminders") }
        item { InfoCard("01", "Secure your base", "Plan storage and exits before expanding your build.") }
        item { InfoCard("02", "Travel light", "Keep essential resources ready before leaving your base.") }
        item { InfoCard("03", "Play fair", "This app provides guides and tools; it does not modify the game or offer cheats.") }
        item { OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.AdminPanelSettings, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Open demo admin") } }
        item { Text("Unofficial fan project. Not affiliated with the Oxide game developers.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) }
    }
}

@Composable
private fun ShopScreen(items: List<ShopItem>, cart: List<CartLine>, onAdd: (ShopItem) -> Unit, onCheckout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text("DIGITAL SHOP", fontSize = 11.sp, color = Mint, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Text("Gear up your knowledge", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("Demo catalogue — prices are examples.", color = Muted, fontSize = 12.sp)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { item ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(52.dp).background(Color(0xFF2B3D45), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Icon(if (item.price == 0) Icons.Default.AutoAwesome else Icons.Default.Inventory2, contentDescription = null, tint = Orange, modifier = Modifier.size(26.dp))
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(item.title, fontWeight = FontWeight.Bold)
                        Text(item.subtitle, color = Muted, fontSize = 12.sp)
                        Text(if (item.price == 0) "FREE" else "${item.price} toman", color = Mint, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    IconButton(onClick = { onAdd(item) }) { Icon(Icons.Default.AddShoppingCart, contentDescription = "Add to cart", tint = Orange) }
                }
            }
        }
        if (cart.isNotEmpty()) Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth().padding(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Ink), shape = RoundedCornerShape(12.dp)) {
            Text("View cart (${cart.sumOf { it.quantity }})", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun OrdersScreen(cart: List<CartLine>, onRemove: (Int) -> Unit, onCheckout: () -> Unit) {
    val total = cart.sumOf { it.item.price * it.quantity }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("YOUR CART", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Review your order", fontSize = 25.sp, fontWeight = FontWeight.Black)
        if (cart.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Muted, modifier = Modifier.size(46.dp))
                    Text("Your cart is empty", color = Muted)
                    Text("Open Shop to add a guide or pack.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cart, key = { it.item.id }) { line ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(line.item.title, fontWeight = FontWeight.Bold)
                            Text("Qty ${line.quantity} · ${line.item.price * line.quantity} toman", color = Mint, fontSize = 12.sp)
                        }
                        TextButton(onClick = { onRemove(line.item.id) }) { Text("Remove", color = Orange) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Estimated total", color = Muted); Text("$total toman", fontWeight = FontWeight.Bold) }
            Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Ink), shape = RoundedCornerShape(12.dp)) { Text("Continue to demo checkout", fontWeight = FontWeight.Bold) }
            Text("No money is charged in this starter project.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ProfileScreen(userName: String, onLogin: () -> Unit, onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("PLAYER PROFILE", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Your account", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(58.dp).background(Color(0xFF30444D), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, contentDescription = null, tint = Mint, modifier = Modifier.size(32.dp)) }
            Column(Modifier.weight(1f)) {
                Text(userName.ifBlank { "Guest player" }, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(if (userName.isBlank()) "Profile not set up" else "Local profile on this device", color = Muted, fontSize = 12.sp)
            }
        }
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Ink), shape = RoundedCornerShape(12.dp)) { Text(if (userName.isBlank()) "Create local profile" else "Edit display name") }
        OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.AdminPanelSettings, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Admin tools (demo)") }
        Text("Account data is currently local and is not synced to a server. Do not use this demo for real authentication or payments.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(eyebrow: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(eyebrow, color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(27.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun InfoCard(number: String, title: String, description: String) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(number, color = Orange, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(description, color = Muted, fontSize = 12.sp)
        }
    }
}
